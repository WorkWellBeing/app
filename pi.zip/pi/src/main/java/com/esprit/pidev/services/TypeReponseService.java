package com.esprit.pidev.services;

import com.esprit.pidev.entities.typereopnse;

public interface TypeReponseService {
	typereopnse addrep(typereopnse  q, Long id);
}
