package com.esprit.pidev.entities;

public enum type {
	General ,Personal_advice,Opinion,News

}
