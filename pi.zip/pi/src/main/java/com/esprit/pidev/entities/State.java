package com.esprit.pidev.entities;

public enum State {
PENDING,ACCEPTED,REJECTED;
}
