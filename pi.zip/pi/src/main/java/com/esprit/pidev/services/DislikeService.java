package com.esprit.pidev.services;

import com.esprit.pidev.entities.Dislike;

public interface DislikeService {
	 
	 Dislike adddislike(Dislike dislike);

}
