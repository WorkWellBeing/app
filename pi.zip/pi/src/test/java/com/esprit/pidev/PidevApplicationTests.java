package com.esprit.pidev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PidevApplicationTests {

	@Test
	void contextLoads() {
	}

}
