package com.esprit.wbeing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WbeingApplicationTests {

    @Test
    void contextLoads() {
    }

}
