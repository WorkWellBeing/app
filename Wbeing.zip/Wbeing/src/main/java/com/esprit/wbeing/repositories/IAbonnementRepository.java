package com.esprit.wbeing.repositories;

import java.util.Date;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.esprit.wbeing.entities.Abonnement;

@Repository
public interface IAbonnementRepository extends CrudRepository<Abonnement, Date>{

}
