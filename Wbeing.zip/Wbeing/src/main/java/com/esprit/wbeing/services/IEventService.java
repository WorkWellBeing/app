package com.esprit.wbeing.services;

import java.util.List;

import com.esprit.wbeing.entities.Event;

public interface IEventService {

	void deleteById(Integer event_id);

	List<Event> getAllEvents();

	public void deleteEvent(Integer event_id);

	

	
	

}
