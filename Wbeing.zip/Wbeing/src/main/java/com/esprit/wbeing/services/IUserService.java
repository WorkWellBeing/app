package com.esprit.wbeing.services;

import java.util.List;

import com.esprit.wbeing.entities.Event;
import com.esprit.wbeing.entities.User;

public interface IUserService {

	

	
	List<Event> afficherEvents(long id_user);

	User CreateUser(User user);

	public void ajouterEtaffecterListeEvents(Event event, Long id_user);
	List<Event> retrieveAllEvents();

	

	

	

	

	

}
