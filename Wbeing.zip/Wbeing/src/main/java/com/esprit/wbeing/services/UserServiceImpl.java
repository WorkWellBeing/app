package com.esprit.wbeing.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esprit.wbeing.entities.Event;
import com.esprit.wbeing.entities.Participation;
import com.esprit.wbeing.entities.User;
import com.esprit.wbeing.repositories.IAbonnementRepository;
import com.esprit.wbeing.repositories.IActivityRepository;
import com.esprit.wbeing.repositories.IEventRepository;
import com.esprit.wbeing.repositories.IParticipationRepository;
import com.esprit.wbeing.repositories.IUserRepository;

import lombok.extern.slf4j.Slf4j;







@Service

public class UserServiceImpl implements IUserService{
	@Autowired
	IUserRepository userRepository;
	@Autowired
	IEventRepository eventRepository;
	@Autowired
	IActivityRepository activityRepository;
	@Autowired
	IParticipationRepository participationRepository;
	@Autowired
	IAbonnementRepository abonnementRepository;
	
	
	
@Override
@Transactional
	public User CreateUser(User user) {
		return userRepository.save(user);
	}


	
	@Override
	@Transactional
	public List< Event>retrieveAllEvents(){
		
		List <Event>EventList =new ArrayList<>();
		eventRepository.findAll().forEach(EventList::add);
		return EventList;
	}
	@Override
	public List<Event> afficherEvents(long id_user) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void ajouterEtaffecterListeEvents(Event event, Long id_user) {
		User user=userRepository.findById(id_user).orElse(null);
		event.setUser(user);
		eventRepository.save(event);
		
	}
	
	
	
	

	
	
	
}
