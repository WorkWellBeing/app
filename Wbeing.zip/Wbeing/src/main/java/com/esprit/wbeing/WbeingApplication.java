package com.esprit.wbeing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WbeingApplication {

    public static void main(String[] args) {
        SpringApplication.run(WbeingApplication.class, args);
    }

}
