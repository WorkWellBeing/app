package com.esprit.wbeing.entities;

public enum State {
PENDING,ACCEPTED,REJECTED;
}
