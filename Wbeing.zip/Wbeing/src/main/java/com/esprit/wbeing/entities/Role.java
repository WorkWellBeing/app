package com.esprit.wbeing.entities;

import java.util.Optional;

public enum Role {
	ADMIN,SIMPLEUSER;
	 // public static Optional<Role> check(String val) {
	        //try { return Optional.of(Role.valueOf(val)); }
	       // catch (Exception e) {/* do nothing */}
	        //return Optional.empty();
	    //}
}
