package com.esprit.wbeing.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esprit.wbeing.entities.Activity;
import com.esprit.wbeing.entities.Event;
import com.esprit.wbeing.entities.Participation;
import com.esprit.wbeing.entities.User;
import com.esprit.wbeing.repositories.IEventRepository;
import com.esprit.wbeing.repositories.IParticipationRepository;
import com.esprit.wbeing.repositories.IUserRepository;

@Service
public class ParticipationServiceImp implements IParticipationService {
	@Autowired
	IUserRepository userRepository;
@Autowired
	IParticipationRepository participationRepository;
@Autowired
IEventRepository eventRepository;

	
	@Override
	public void ajouterEtaffecterPartToEvent(Participation part, String name) {
		Event event=eventRepository.findByName(name).orElse(null);
		part.setEvent(event);
		participationRepository.save(part);
		
	}


	@Override
	public void ajouterEtaffecterListeParts(Participation part, Long id_user, Integer event_id) {
		User user=userRepository.findById(id_user).orElse(null);
		Event event=eventRepository.findById(event_id).orElse(null);
		part.setUser(user);
		part.setEvent(event);
		participationRepository.save(part);
	}

	
	
	

}
