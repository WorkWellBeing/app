package com.esprit.wbeing.controllers;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.esprit.wbeing.entities.Event;
import com.esprit.wbeing.entities.User;
import com.esprit.wbeing.repositories.IEventRepository;
import com.esprit.wbeing.services.IEventService;
import com.esprit.wbeing.services.IUserService;


@RestController
@RequestMapping("/User")
public class UserRestController {
	@Autowired(required = true)
	public IUserService userService;
	
	@Autowired(required=true)
	public IEventService eventService;
	
	
	@PostMapping("/add-user")
	public void addUser(@RequestBody User user) {
		 userService.CreateUser(user);
	}
	
	@PostMapping("/add-event/{id-user}")
	public void addEvent(@RequestBody Event event,@PathVariable(value = "id-user") Long id_user ) 
	{
		userService.ajouterEtaffecterListeEvents(event, id_user);

	}
	
	@GetMapping("/retrieve_events")
	@ResponseBody
	public List<Event> getEvents() {
	List<Event> listEvents =  userService.retrieveAllEvents();
	return  listEvents;
	}
	
	@DeleteMapping("/delete-event/{event_id}")
	public void deleteEvents( @PathParam(value="event_id")Integer event_id) {
		if (event_id!=null) {
		eventService.deleteById(event_id);}
		
	}
	@GetMapping("/afficher-events")
	@ResponseBody
	public List<Event>getAllEvents(){
		List<Event>listeEvents=eventService.getAllEvents();
		return listeEvents;
	}
	
	
}