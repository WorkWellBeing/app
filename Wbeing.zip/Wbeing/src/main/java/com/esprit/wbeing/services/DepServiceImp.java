package com.esprit.wbeing.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esprit.wbeing.entities.Department;
import com.esprit.wbeing.repositories.DepRepository;

@Service
public class DepServiceImp  implements IDepService{
	@Autowired
	DepRepository depRepository;

	@Override
	public Department saveDepartment(Department department) {
		
		return depRepository.save(department);
	}

	@Override
	public List<Department> findallDepartments() {
		// TODO Auto-generated method stub
		return (List<Department>) depRepository.findAll();
	}

	@Override
	public Department updateDepartment(Department department) {
		
		return depRepository.save(department);
	}

	@Override
	public void deleteDep(Integer Dep_id) {
		
			depRepository.deleteById(Dep_id);
			
		}
		
	

	

}
