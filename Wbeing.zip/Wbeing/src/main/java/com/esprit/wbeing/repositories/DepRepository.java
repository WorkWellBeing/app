package com.esprit.wbeing.repositories;

import org.springframework.data.repository.CrudRepository;

import com.esprit.wbeing.entities.Department;

public interface DepRepository extends CrudRepository<Department, Integer> {

}
