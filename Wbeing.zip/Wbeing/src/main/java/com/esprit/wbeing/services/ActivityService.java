package com.esprit.wbeing.services;

import java.util.List;

import com.esprit.wbeing.entities.Activity;
import com.esprit.wbeing.entities.Department;
import com.esprit.wbeing.entities.Event;

public interface ActivityService {
	public void ajouterEtaffecterListeActs(Activity act, Long id_user);
	public void deleteAct(Integer activity_id);
	public Department updateAct(Activity activity);
	public List<Activity>findallacActivities();

}
